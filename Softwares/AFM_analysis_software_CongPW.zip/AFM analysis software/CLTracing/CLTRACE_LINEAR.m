% CLTRACE.M
%
% This function tracing the center line of the DNA molecule

function [centerLine]=CLTRACE(image, stepLength, oneSideNum,windowSize)

if nargin<4
    windowSize=5; end
if nargin<3
    oneSideNum=5; end
if nargin<2
    stepLength=3; end

oneSideNumStore=oneSideNum;

% information about the image
imageSize=size(image);
r=imageSize(1);
c=imageSize(2);

% get the Brightness matrix (bigger, brighter)
imageBrightness=zeros(r,c);
for i=1:r
    for j=1:c
        imageBrightness(i,j)=sum(image(i,j,:));
    end
end

% initialization Find the First Centrol Point

MiddleX=round(r/2);
MiddleY=round(c/2);
MiddlePoint=[MiddleX MiddleY];
initheta=0;
inia=sin(initheta);
inib=cos(initheta);
[x y bright]=WALKLINE(imageBrightness,inia,inib,MiddlePoint,MiddleX-1,30);

% recursively find the point on the DNA molecule
while bright<=1 %consider this
    initheta=initheta+pi/8;
    inia=sin(initheta);
    inib=cos(initheta);
    [x y bright]=WALKLINE(imageBrightness,inia,inib,MiddlePoint,MiddleX-1,30);
end

% initialization of centerLine
iniPoint=[x y];
currentPoint=iniPoint;
b=0;
a=-MiddleY;
centerLineTmp=[];
centerLineTmp(1,:)=iniPoint; % push first currentPoint in

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% go along the y to the left
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

lastPoint=[x y+1]; % define initial lastPoint

% recursively searching for current points

while (currentPoint(1) < (r-stepLength)) && (currentPoint(1) > stepLength) && (currentPoint(2) > stepLength) && (currentPoint(2) < (c-stepLength)) && (imageBrightness(currentPoint(1),currentPoint(2))>0)
    %first enter
    done=0;
    while ~done
        [trialPoint Newa Newb]=TRIALLINEFIRST(imageBrightness, a, b, currentPoint, lastPoint, stepLength, oneSideNum, windowSize);
        index=0;
        while [trialPoint Newa Newb]==[[-1 -1] -1 -1]
            tmpa=sin(atan(-a/b)+(-1)^index*round((index+1)/2)*pi/32);
            tmpb=cos(atan(-a/b)+(-1)^index*round((index+1)/2)*pi/32);
            % turn pi/8
            [trialPoint Newa Newb]=TRIALLINEFIRST(imageBrightness, tmpa, tmpb, currentPoint, lastPoint, stepLength, oneSideNum, windowSize);
            index=index+1;
            if index==32
                break;
            end
        end

        pTrialPoint=trialPoint;
        a=Newa;
        b=Newb;

        for i=1:5
            [trialPoint Newa Newb]=TRIALLINE(imageBrightness, a, b, currentPoint, pTrialPoint, stepLength, oneSideNum, windowSize);
            index=0;
            while [trialPoint Newa Newb]==[[-1 -1] -1 -1]
                tmpa=sin(atan(-a/b)+(-1)^index*round((index+1)/2)*pi/32);
                tmpb=cos(atan(-a/b)+(-1)^index*round((index+1)/2)*pi/32);
                % turn pi/8
                [trialPoint Newa Newb]=TRIALLINE(imageBrightness, tmpa, tmpb, currentPoint, pTrialPoint, stepLength, oneSideNum, windowSize);
                index=index+1;
                if index==32
                    break;
                end
            end
            pTrialPoint=trialPoint;
            a=Newa;
            b=Newb;
        end
        
        if CHECKNEAR(currentPoint, trialPoint, stepLength)
            lastLastPoint=lastPoint;
            lastPoint=currentPoint;
            currentPoint=trialPoint;
            oneSideNum=oneSideNumStore;
            done=1;
        else
            oneSideNum=round(oneSideNum/2);
        end
    end
    
    if CHECKSTOP(currentPoint, lastPoint, lastLastPoint)
        break;
    else
        centerLineTmpSize=size(centerLineTmp);
        centerLineTmp((centerLineTmpSize(1)+1),:)=currentPoint;
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% order the points
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

centerLine=[];
centerLineTmpSize=size(centerLineTmp,1);
for i=1:centerLineTmpSize
    centerLine(i,:)=centerLineTmp(centerLineTmpSize-i+1,:);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% go along the y to the right
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% re-initrialize

currentPoint=iniPoint;
b=0;
a=-MiddleY;

lastPoint=[x y-1]; % define initial lastPoint

% recursively searching for current points

while (currentPoint(1) < (r-stepLength)) && (currentPoint(1) > stepLength) && (currentPoint(2) > stepLength) && (currentPoint(2) < (c-stepLength)) && (imageBrightness(currentPoint(1),currentPoint(2))>0)
    %first enter
    done=0;
    while ~done
        [trialPoint Newa Newb]=TRIALLINEFIRST(imageBrightness, a, b, currentPoint, lastPoint, stepLength, oneSideNum, windowSize);
        index=0;
        while [trialPoint Newa Newb]==[[-1 -1] -1 -1]
            newTheta=atan(-a/b)+(-1)^index*round((index+1)/2)*pi/32;
            tmpa=sin(newTheta);
            tmpb=cos(newTheta);
            % turn pi/8
            [trialPoint Newa Newb]=TRIALLINEFIRST(imageBrightness, tmpa, tmpb, currentPoint, lastPoint, stepLength, oneSideNum, windowSize);
            index=index+1;
            if index==32
                break;
            end
        end

        pTrialPoint=trialPoint;
        a=Newa;
        b=Newb;

        for i=1:5
            [trialPoint Newa Newb]=TRIALLINE(imageBrightness, a, b, currentPoint, pTrialPoint, stepLength, oneSideNum, windowSize);
            index=0;
            while [trialPoint Newa Newb]==[[-1 -1] -1 -1]
                tmpa=sin(atan(-a/b)+(-1)^index*round((index+1)/2)*pi/32);
                tmpb=cos(atan(-a/b)+(-1)^index*round((index+1)/2)*pi/32);
                % turn pi/8
                [trialPoint Newa Newb]=TRIALLINE(imageBrightness, tmpa, tmpb, currentPoint, pTrialPoint, stepLength, oneSideNum, windowSize);
                index=index+1;
                if index==32
                    break;
                end
            end
            pTrialPoint=trialPoint;
            a=Newa;
            b=Newb;
        end
        if CHECKNEAR(currentPoint, trialPoint, stepLength)
            lastLastPoint=lastPoint;
            lastPoint=currentPoint;
            currentPoint=trialPoint;
            oneSideNum=oneSideNumStore;
            done=1;
        else
            oneSideNum=round(oneSideNum/2);
        end
    end
    
    if CHECKSTOP(currentPoint, lastPoint, lastLastPoint)
        break;
    else
        centerLineSize=size(centerLine);
        centerLine((centerLineSize(1)+1),:)=currentPoint;
    end
end
