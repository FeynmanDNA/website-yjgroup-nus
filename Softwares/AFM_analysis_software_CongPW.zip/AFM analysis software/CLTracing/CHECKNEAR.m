% CHECKNEAR.M
%
% This function checks whether store point by checking the distance between
% newTrialPoint and currentPoint is roughly stepLength.

function [storeOrNot]=CHECKNEAR(currentPoint, trialPoint, stepLength)

currentX=currentPoint(1);
currentY=currentPoint(2);

trialX=trialPoint(1);
trialY=trialPoint(2);

dis=(currentX-trialX)^2+(currentY-trialY)^2;
disThredhold=(1.5*stepLength)^2;

if dis>disThredhold
    storeOrNot=false;
else
    storeOrNot=true;
end