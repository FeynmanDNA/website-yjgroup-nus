function outPut=crSpline(Px, Py, Tension, n)

%%%% Cardinal Spline 2D Interpolation %%%%%%%%%%
Px=[Px(1) Px' Px(length(Px))];	
Py=[Py(1) Py' Py(length(Py))];	
% Note first and last points are repeated so that spline curve passes
% through all points

% when Tension=0 the class of Cardinal spline is known as Catmull-Rom
% spline

outPut=[];

for k=1:length(Px)-3
    
    [MatOut2]=crdatnplusoneval([Px(k),Py(k)],[Px(k+1),Py(k+1)],[Px(k+2),Py(k+2)],[Px(k+3),Py(k+3)],Tension,n);
    
    outPut=[outPut MatOut2];
end

outPut=outPut';