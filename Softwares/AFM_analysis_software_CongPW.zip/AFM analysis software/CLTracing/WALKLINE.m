% WALKLINE.M
%
% This function obtains the coordination of the Brightest point on the line

function [X Y Brightness]=WALKLINE(imageBrightness, a, b, centerPoint, oneSideNum, windowSize)

% The line is in the form of ax+by+c=0.
% centerPoint is the point centered at the totalNum on the line.
% oneSideNum is the number of points on one side of the center point.


centerX=centerPoint(1);
centerY=centerPoint(2);
c=-a*centerX-b*centerY;

% protection out of boundery
imageSize=size(imageBrightness);
row=imageSize(1);
column=imageSize(2);

brightestWindowWeight=0;
totalWindowWeight=0;

if a==0
    startX=centerX-oneSideNum;
    endX=centerX+oneSideNum;

    if startX<1
        startX=1; end
    if endX>row
       endX=row; end

    % initialization of window (a==0)
    startXWindow=startX;
    endXWindow=endX-windowSize+1;
    realStartX=startX;
    
    for i=startXWindow:endXWindow
        for j=i:(i+windowSize-1)
            x=j;
            y=centerY;
            bright=imageBrightness(x,y);
            totalWindowWeight=totalWindowWeight+bright;
        end
        if totalWindowWeight>brightestWindowWeight
            brightestWindowWeight=totalWindowWeight;
            realStartX=i;
        end
        totalWindowWeight=0;
    end
elseif b==0
    
    startY=centerY-oneSideNum;
    endY=centerY+oneSideNum;
    
    if startY<1
        startY=1; end
    if endY>column
        endY=column; end
    
    %initialization of window (b==0)
    startYWindow=startY;
    endYWindow=endY-windowSize+1;
    realStartY=startY;

    
    for i=startYWindow:endYWindow
        for j=i:(i+windowSize-1)
            x=centerX;
            y=j;
            bright=imageBrightness(x,y);
            totalWindowWeight=totalWindowWeight+bright;
        end
        if totalWindowWeight>brightestWindowWeight
            brightestWindowWeight=totalWindowWeight;
            realStartY=i;
        end
        totalWindowWeight=0;
    end
else
    if (abs(-a/b)<=1)
        
        startX=centerX-oneSideNum;
        endX=centerX+oneSideNum;

        if startX<1
            startX=1; end
        if endX>row
           endX=row; end

        % initialization of window (a!=0 && b!=0)
        startXWindow=startX;
        endXWindow=endX-windowSize+1;
        realStartX=startX;
        
        for i=startXWindow:endXWindow
            for j=i:(i+windowSize-1)
                x=j;
                y=abs(round((j+c/a)*(-a/b)));
                if y>0 && y<(column+1) % protect
                    bright=imageBrightness(x,y);
                    totalWindowWeight=totalWindowWeight+bright;
                end
            end
            if totalWindowWeight>brightestWindowWeight
                brightestWindowWeight=totalWindowWeight;
                realStartX=i;
            end
            totalWindowWeight=0;
        end
    else
        
        startY=centerY-oneSideNum;
        endY=centerY+oneSideNum;

        if startY<1
            startY=1; end
        if endY>column
            endY=column; end

        %initialization of window (b==0)
        startYWindow=startY;
        endYWindow=endY-windowSize+1;
        realStartY=startY;
        
        for i=startYWindow:endYWindow
            for j=i:(i+windowSize-1)
                y=j;
                x=abs(round((j+c/b)*(-b/a)));
                if x>0 && x<(row+1) % protect
                    bright=imageBrightness(x,y);
                    totalWindowWeight=totalWindowWeight+bright;
                end
            end
            if totalWindowWeight>brightestWindowWeight
                brightestWindowWeight=totalWindowWeight;
                realStartY=i;
            end
            totalWindowWeight=0;
        end
    end
end

totalWeight=0;
weightXWithoutNorm=0;
weightYWithoutNorm=0;

if a==0
    
    y=centerY;
    for i=realStartX:(realStartX+windowSize-1)
        x=i;
        bright=imageBrightness(x,y);
        totalWeight=totalWeight+bright;
        weightXWithoutNorm=weightXWithoutNorm+x*bright;
        weightYWithoutNorm=weightYWithoutNorm+y*bright;
    end
elseif b==0
    
    x=centerX;
    for i=realStartY:(realStartY+windowSize-1)
        y=i;
        bright=imageBrightness(x,y);
        totalWeight=totalWeight+bright;
        weightXWithoutNorm=weightXWithoutNorm+x*bright;
        weightYWithoutNorm=weightYWithoutNorm+y*bright;
    end
else
    if (abs(-a/b)<=1)
        for i=realStartX:(realStartX+windowSize-1)
            x=i;
            y=abs(round((i+c/a)*(-a/b)));
            if y>0 && y<(column+1) % protect
                bright=imageBrightness(x,y);
                totalWeight=totalWeight+bright;
                weightXWithoutNorm=weightXWithoutNorm+x*bright;
                weightYWithoutNorm=weightYWithoutNorm+y*bright;
            end
        end
    else
        for i=realStartY:(realStartY+windowSize-1)
            y=i;
            x=abs(round((i+c/b)*(-b/a)));
            if x>0 && x<(row+1) % protect
                bright=imageBrightness(x,y);
                totalWeight=totalWeight+bright;
                weightXWithoutNorm=weightXWithoutNorm+x*bright;
                weightYWithoutNorm=weightYWithoutNorm+y*bright;
            end
        end
    end
end

if totalWeight==0
    X=-1;
    Y=-1;
    Brightness=-1;
else
    X=round(weightXWithoutNorm/totalWeight);
    Y=round(weightYWithoutNorm/totalWeight);
    Brightness=imageBrightness(X,Y);
end