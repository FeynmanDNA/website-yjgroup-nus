% CHECKEND.M
%
% This function checks if end the tracing by comparing the distance between
% newTrialPoint and iniPoint

function [endOrNot]=CHECKEND(currentPoint, iniPoint, stepLength)

currentX=currentPoint(1);
currentY=currentPoint(2);

iniX=iniPoint(1);
iniY=iniPoint(2);

dis=(currentX-iniX)^2+(currentY-iniY)^2;
disThredhold=(stepLength)^2;

if dis<disThredhold
    endOrNot=true;
else
    endOrNot=false;
end