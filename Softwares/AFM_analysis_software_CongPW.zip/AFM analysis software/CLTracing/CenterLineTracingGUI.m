function varargout = CenterLineTracingGUI(varargin)
% CENTERLINETRACINGGUI M-file for CenterLineTracingGUI.fig
%      CENTERLINETRACINGGUI, by itself, creates a new CENTERLINETRACINGGUI or raises the existing
%      singleton*.
%
%      H = CENTERLINETRACINGGUI returns the handle to a new CENTERLINETRACINGGUI or the handle to
%      the existing singleton*.
%
%      CENTERLINETRACINGGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in CENTERLINETRACINGGUI.M with the given input arguments.
%
%      CENTERLINETRACINGGUI('Property','Value',...) creates a new CENTERLINETRACINGGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before CenterLineTracingGUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to CenterLineTracingGUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help CenterLineTracingGUI

% Last Modified by GUIDE v2.5 18-Apr-2008 00:52:27

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @CenterLineTracingGUI_OpeningFcn, ...
                   'gui_OutputFcn',  @CenterLineTracingGUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before CenterLineTracingGUI is made visible.
function CenterLineTracingGUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to CenterLineTracingGUI (see VARARGIN)

% Initialization
set(handles.imageLocation, 'String', '');
set(handles.clLocation, 'String', '');
set(handles.splineLocation, 'String', '');
set(handles.threshold, 'Value', 0.05);
set(handles.diskSize, 'Value', 3);
set(handles.stepSize, 'Value', 2);
set(handles.lineSize, 'value', 11);
set(handles.width, 'Value', 3);
set(handles.interpolationNum, 'String', '100');

set(handles.thresholdVal, 'String', '0.05');
set(handles.diskSizeVal, 'String', '3');
set(handles.stepSizeVal, 'String', '2');
set(handles.lineSizeVal, 'String', '11');
set(handles.widthVal, 'String', '3');

hold off;
imshow(zeros(300,300,3));

% Choose default command line output for CenterLineTracingGUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes CenterLineTracingGUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = CenterLineTracingGUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in close.
function close_Callback(hObject, eventdata, handles)
% hObject    handle to close (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

close all;

% --- Executes on button press in trace.
function trace_Callback(hObject, eventdata, handles)
% hObject    handle to trace (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get parameters
imageLocation = get(handles.imageLocation, 'String');
threshold = get(handles.threshold, 'Value');
diskSize = get(handles.diskSize, 'Value');
stepSize = get(handles.stepSize, 'Value');
lineSize = get(handles.lineSize, 'value');
oneSizeNum = (lineSize - 1)/2;
width = get(handles.width, 'Value');
interpolationNum = str2double(get(handles.interpolationNum, 'String'));
tension = 0;

% Reduce the Noise
image = NOISERD(imageLocation, threshold, diskSize);

% Center Line Tracing
if (get(handles.linearDNA,'Value') == get(hObject,'Max'))
	% Radio button linearDNA is selected, take appropriate action
    centerline = CLTRACE_LINEAR(image, stepSize, oneSizeNum, width);
else
	% Radio button linearDNA is not selected, take appropriate action
    centerline = CLTRACE_CIRCULAR(image, stepSize, oneSizeNum, width);
end

handles.centerline = centerline;

% Plotting
if (get(handles.originImage,'Value') == get(handles.originImage,'Max'))
	% OriginImage is checked-take approriate action
    imshow(imageLocation);
else
	% OriginImage is not checked-take approriate action
    imshow(image);
end

hold on;

if (get(handles.spline,'Value') == get(handles.spline,'Max'))
	% OriginImage is checked-take approriate action
    
    % Interpolation
    interpolation = crSpline(centerline(:,1), centerline(:,2), tension, interpolationNum);
    handles.interpolation = interpolation;
    
    plot(interpolation(:,2), interpolation(:,1), 'b.');
else
	% OriginImage is not checked-take approriate action
    plot(centerline(:,2),centerline(:,1),'r.');
end

hold off;

guidata(hObject, handles);

% --- Executes on slider movement.
function threshold_Callback(hObject, eventdata, handles)
% hObject    handle to threshold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

newThreshold = get(hObject, 'Value');
set(handles.thresholdVal, 'String', num2str(newThreshold));

% --- Executes during object creation, after setting all properties.
function threshold_CreateFcn(hObject, eventdata, handles)
% hObject    handle to threshold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function diskSize_Callback(hObject, eventdata, handles)
% hObject    handle to diskSize (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

newDiskSize = get(hObject, 'Value');
set(handles.diskSizeVal, 'String', num2str(newDiskSize));

% --- Executes during object creation, after setting all properties.
function diskSize_CreateFcn(hObject, eventdata, handles)
% hObject    handle to diskSize (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function stepSize_Callback(hObject, eventdata, handles)
% hObject    handle to stepSize (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

newStepSize = get(hObject, 'Value');
set(handles.stepSizeVal, 'String', num2str(newStepSize));

% --- Executes during object creation, after setting all properties.
function stepSize_CreateFcn(hObject, eventdata, handles)
% hObject    handle to stepSize (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function lineSize_Callback(hObject, eventdata, handles)
% hObject    handle to lineSize (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

newLineSize = get(hObject, 'Value');
set(handles.lineSizeVal, 'String', num2str(newLineSize));

% --- Executes during object creation, after setting all properties.
function lineSize_CreateFcn(hObject, eventdata, handles)
% hObject    handle to lineSize (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function width_Callback(hObject, eventdata, handles)
% hObject    handle to width (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

newWidth = get(hObject, 'Value');
set(handles.widthVal, 'String', num2str(newWidth));

% --- Executes during object creation, after setting all properties.
function width_CreateFcn(hObject, eventdata, handles)
% hObject    handle to width (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on button press in loadImage.
function loadImage_Callback(hObject, eventdata, handles)
% hObject    handle to loadImage (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

hold off;
imageLocation = get(handles.imageLocation, 'String');
imshow(imageLocation);

function imageLocation_Callback(hObject, eventdata, handles)
% hObject    handle to imageLocation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of imageLocation as text
%        str2double(get(hObject,'String')) returns contents of imageLocation as a double


% --- Executes during object creation, after setting all properties.
function imageLocation_CreateFcn(hObject, eventdata, handles)
% hObject    handle to imageLocation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function clLocation_Callback(hObject, eventdata, handles)
% hObject    handle to clLocation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of clLocation as text
%        str2double(get(hObject,'String')) returns contents of clLocation as a double


% --- Executes during object creation, after setting all properties.
function clLocation_CreateFcn(hObject, eventdata, handles)
% hObject    handle to clLocation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in saveCenterline.
function saveCenterline_Callback(hObject, eventdata, handles)
% hObject    handle to saveCenterline (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

centerline = handles.centerline;
clLocation = get(handles.clLocation, 'String');
save(clLocation, 'centerline', '-ASCII');


% --- Executes on button press in originImage.
function originImage_Callback(hObject, eventdata, handles)
% hObject    handle to originImage (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of originImage


% --- Executes on button press in spline.
function spline_Callback(hObject, eventdata, handles)
% hObject    handle to spline (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of spline



function splineLocation_Callback(hObject, eventdata, handles)
% hObject    handle to splineLocation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of splineLocation as text
%        str2double(get(hObject,'String')) returns contents of splineLocation as a double


% --- Executes during object creation, after setting all properties.
function splineLocation_CreateFcn(hObject, eventdata, handles)
% hObject    handle to splineLocation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in saveInterpolation.
function saveInterpolation_Callback(hObject, eventdata, handles)
% hObject    handle to saveInterpolation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

interpolation = handles.interpolation;
splineLocation = get(handles.splineLocation, 'String');
save(splineLocation, 'interpolation', '-ASCII');

function interpolationNum_Callback(hObject, eventdata, handles)
% hObject    handle to interpolationNum (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of interpolationNum as text
%        str2double(get(hObject,'String')) returns contents of interpolationNum as a double


% --- Executes during object creation, after setting all properties.
function interpolationNum_CreateFcn(hObject, eventdata, handles)
% hObject    handle to interpolationNum (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in linearDNA.
function linearDNA_Callback(hObject, eventdata, handles)
% hObject    handle to linearDNA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of linearDNA

set(handles.circularDNA, 'Value', 0);

% --- Executes on button press in circularDNA.
function circularDNA_Callback(hObject, eventdata, handles)
% hObject    handle to circularDNA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of circularDNA

set(handles.linearDNA, 'Value', 0);

% --- Executes on button press in noiseRD.
function noiseRD_Callback(hObject, eventdata, handles)
% hObject    handle to noiseRD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get parameters
imageLocation = get(handles.imageLocation, 'String');
threshold = get(handles.threshold, 'Value');
diskSize = get(handles.diskSize, 'Value');

% Reduce the Noise
image = NOISERD(imageLocation, threshold, diskSize);

hold off;
imshow(image);
