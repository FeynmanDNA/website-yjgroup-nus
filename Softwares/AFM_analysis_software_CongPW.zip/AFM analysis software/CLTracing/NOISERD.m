% NOISERD.M
%
% This M file helps to reduce the noise of image by selecting the main
% object only.

function [imageNoNoise row column]=NOISERD(filename,grayThresholdValue,seDiskSize)

%set default
if nargin<3
    seDiskSize=2; end
if nargin<2
    grayThresholdValue=0.05; end

image=imread(filename); % input
se=strel('disk',seDiskSize);
imageBackground=imopen(image,se);
imageNoBackground=image-imageBackground;
% to gray
% adjust
grayThreshold=grayThresholdValue; % better to be danymic
imageBW=im2bw(imageNoBackground,grayThreshold);
[imageBWLabel, objCount]=bwlabel(imageBW,4);

% find the row and column indices of the main object
mainObjSize=1;
for i=1:objCount
    [r,c]=find(imageBWLabel==i);
    if length(r)>mainObjSize;
        mainObjSize=length(r);
        row=r;
        column=c;
    end
end

% get the information from imgae indixed by [row,column]
imageSize=size(image);
imageNoNoise=zeros(imageSize);
indices=[row,column];

for i=1:mainObjSize
    curXIndices=indices(i,1);
    curYIndices=indices(i,2);
    imageNoNoise(curXIndices, curYIndices,:)=image(curXIndices, curYIndices,:);
end

    