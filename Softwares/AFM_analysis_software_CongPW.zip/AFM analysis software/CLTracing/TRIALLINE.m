% TRIALLINE.M
%
% This function locate the trial point on the perpanticular line of the
% segment.

function [trialPoint Newa Newb]=TRIALLINE(imageBrightness, a, b, currentPoint, pTrialPoint, stepLength, oneSideNum, windowSize)

% The tangent line is in the form of ax+by+c=0.
% currentPoint is the pre-fixed point on the line.
% stepLength is the Euclidean distance from trial point to current point
% dire 0: x positive direction 1: x negative direction


if nargin<6
    oneSideNum=5; end
if nargin<5
    stepLength=5; end

currentX=currentPoint(1);
currentY=currentPoint(2);

% direction indicator
indicX=pTrialPoint(1)-currentX;
indicY=pTrialPoint(2)-currentY;

if a==0
    
    centerY=currentY;
    if indicX>0
        centerX=currentX+stepLength;
    else
        centerX=currentX-stepLength;
    end
    
elseif b==0
    
    centerX=currentX;
    if indicY>0
        centerY=currentY+stepLength;
    else
        centerY=currentY-stepLength;
    end
    
else
    
    if (abs(-a/b)<=1)
        
        if indicX>0 %pushing down
            
            centerX=currentX+ceil((abs(b)/sqrt(a^2+b^2))*stepLength);
            centerY=currentY+round((centerX-currentX)*(-a/b));

        else %pushing up
            
            centerX=currentX-ceil((abs(b)/sqrt(a^2+b^2))*stepLength);
            centerY=currentY+round((centerX-currentX)*(-a/b));
            
        end

    else
        if indicY>0 %pushing right
            
            centerY=currentY+ceil((abs(a)/sqrt(a^2+b^2))*stepLength);
            centerX=currentX+round((centerY-currentY)*(-b/a));

        else %pushing left
            
            centerY=currentY-ceil((abs(a)/sqrt(a^2+b^2))*stepLength);
            centerX=currentX+round((centerY-currentY)*(-b/a));
            
        end
    end
end

centerPoint=[centerX centerY];

[x y bright]=WALKLINE(imageBrightness, -b, a, centerPoint, oneSideNum, windowSize);
if [x y bright] == [-1 -1 -1]
    trialPoint=[-1 -1];
    Newb=-1;
    Newa=-1;
else
    trialPoint=[x y];
    Newb=-(x-currentX);
    Newa=y-currentY;
end