% CHECKSTOP.M
%
% This function checks if stop by comparing the distance between newTrialPoint and lastPoint,
% and that between newTrialPoint and the point before last point.

function [stopOrNot]=CHECKSTOP(currentPoint, lastPoint, lastLastPoint)

currentX=currentPoint(1);
currentY=currentPoint(2);

lastX=lastPoint(1);
lastY=lastPoint(2);

lastLastX=lastLastPoint(1);
lastLastY=lastLastPoint(2);

disNew=(currentX-lastX)^2+(currentY-lastY)^2;
disOld=(currentX-lastLastX)^2+(currentY-lastLastY)^2;

if disNew<disOld
    stopOrNot=false;
else
    stopOrNot=true;
end