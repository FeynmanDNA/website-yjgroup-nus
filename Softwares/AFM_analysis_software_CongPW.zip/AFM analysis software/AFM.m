function varargout = AFM(varargin)
% AFM M-file for AFM.fig
%      AFM, by itself, creates a new AFM or raises the existing
%      singleton*.
%
%      H = AFM returns the handle to a new AFM or the handle to
%      the existing singleton*.
%
%      AFM('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in AFM.M with the given input arguments.
%
%      AFM('Property','Value',...) creates a new AFM or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before AFM_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to AFM_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help AFM

% Last Modified by GUIDE v2.5 27-Jan-2011 01:31:09

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @AFM_OpeningFcn, ...
                   'gui_OutputFcn',  @AFM_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before AFM is made visible.
function AFM_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to AFM (see VARARGIN)

% Choose default command line output for AFM
handles.output = hObject;

% Update handles structure
points = [];
handles.points = points; % initialize points array 
guidata(hObject, handles);

% UIWAIT makes AFM wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = AFM_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



% --- Executes on button press in browse_pushbutton.
function browse_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to browse_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[FileName,PathName] = uigetfile('*.jpeg', '*.jpg','Select AFM image');
Source = strcat(PathName, FileName);
I1 = imread(Source);
axes(handles.axes1)
imshow(I1);
hold
handles.global_trace_x = [];
handles.global_trace_y = [];
axes(handles.axes2)
I2 = rgb2gray(I1);
handles.I1 = I1;
handles.I2 = I2;
imshow(I2);
guidata(hObject, handles);


% --- Executes on slider movement.
function threshold_slider_Callback(hObject, eventdata, handles)
% hObject    handle to threshold_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
threshold_value = get(hObject, 'Value');
I2 = handles.I2;
I3 = im2bw(I2,threshold_value);
axes(handles.axes2)
imshow(I3)

handles.I3 = I3;

set(handles.threshold_static, 'string', threshold_value);

guidata(hObject, handles);



% --- Executes during object creation, after setting all properties.
function threshold_slider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to threshold_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on button press in filter_pushbutton.
function filter_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to filter_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
I3 = handles.I3;
I4 = medfilt2(I3, [3 3]);
axes(handles.axes2)
imshow(I4)
handles.I4 = I4;
guidata(hObject, handles);


% --- Executes on button press in skel_pushbutton.
function skel_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to skel_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
I4 = handles.I4;
I5 = bwmorph(I4, 'thin', inf);
I6 = I5; %backup original image

axes(handles.axes2)
imshow(I5)

handles.I5 = I5;
handles.I6 = I6;
guidata(hObject, handles);


% --- Executes on button press in measure_pushbutton.
function measure_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to measure_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global_trace_x = handles.global_trace_x;
global_trace_y = handles.global_trace_y;

image = handles.I5;
points = handles.points;
axes(handles.axes2)
hold on;
temp_size = size(points);
points_length = temp_size(1);

Ne = 0; %set counter for turns
No = 0;
seq = []; %sequence of events
trace_x = [];
trace_y = [];
temp_image =image;

for i = 1:points_length-1
    stop = 0;
    while stop ~= 1 
        starting_x = points(i,1); %define starting x 
        starting_y = points(i,2); %define starting y
        ending_x = points(i+1,1); %define ending x
        ending_y = points(i+1,2); %define ending y
        temp_image = image; %%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%matrix and array initialization%%%%%%%%%%%%%%%%%%%%
        temp_Ne = 0; %set counter for turns
        temp_No = 0;
        temp_seq = []; %sequence of events
        temp_trace_x = []; %
        temp_trace_y = []; %collection of polymer tracing
        %temp_image = image; %load temporary image for tracking

        mat_y = [-1,-1,-1; 0,0,0; 1,1,1]; %
        mat_x = [-1,0,1; -1,0,1; -1,0,1]; %elongation matrix
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        cur_x = starting_x; %
        cur_y = starting_y; %define the current position of tracing

        temp_image(starting_y, starting_x) = 0; %delete focus point
        M = temp_image(starting_y-1:starting_y+1, starting_x-1:starting_x+1);

        ind = find(M); %find non-zero elements.
        
        ind_size = size(ind);
        ind_length = ind_size(1); %the number of non-zero elements.
        ind_rand = ceil(rand(1)*ind_length); %round up random integers.
        ind_choosen = ind(ind_rand); %re-update ind for randomly selected non-zero single indices

        if mod(ind_choosen,2) == 0
            temp_Ne = temp_Ne + 1; % if even ind
            temp_seq = [temp_seq 0]; % add zero if even 
        else
            temp_No = temp_No + 1; % if odd ind
            temp_seq = [temp_seq 1]; % add 1 if odd
        end

        temp_trace_x = [temp_trace_x cur_x]; %
        temp_trace_y = [temp_trace_y cur_y]; %append current pos to tracing log

        for j=1:ind_length
        temp_image(cur_y + mat_y(ind(j)), cur_x + mat_x(ind(j)))= 0; %delete all non zero values in the vicinity. 
        end

        while ind ~= 0 %ind = 0 means end of a trace, terminate loop at end of a random trace
            cur_x = cur_x + mat_x(ind_choosen); %
            cur_y = cur_y + mat_y(ind_choosen); %move the trace forward to selected direction
            temp_trace_x = [temp_trace_x cur_x]; %
            temp_trace_y = [temp_trace_y cur_y]; %append current pos to tracing log

            temp_image(cur_y, cur_x) = 0; %set current position 1 to 0;

            M = temp_image(cur_y-1:cur_y+1, cur_x-1:cur_x+1); %get current 3x3 matrix

            ind = find(M); %update indice of the next polymer segment
            
            if isempty(ind) == 1
                break
            elseif (cur_x == ending_x && cur_y == ending_y)
                break
                stop = 1;
            end
%             
            
            ind_size = size(ind);
            ind_length = ind_size(1); %the number of non-zero elements.
            ind_rand = ceil(rand(1)*ind_length); %round up random integers.
            ind_choosen = ind(ind_rand); %re-update ind for randomly selected non-zero single indices
            
            for j=1:ind_length
                temp_image(cur_y + mat_y(ind(j)), cur_x + mat_x(ind(j)))= 0; %delete all non zero values in the vicinity. 
            end
            

            
            %%Updating the Ne, No and seq list%%
            if mod(ind_choosen,2) == 0
                temp_Ne = temp_Ne + 1; % if even ind
                temp_seq = [temp_seq 0]; % add zero if even 
            elseif mod(ind_choosen,2) == 1
                temp_No = temp_No + 1; % if odd ind
                temp_seq = [temp_seq 1]; % add 1 if odd
            end 
        end
        
        if (cur_x == ending_x && cur_y == ending_y)
            image = temp_image;%%%%%%%%%%%%
            break; %break out of the while loop if it hits the end point    
            stop = 1 %if current position similar to ending point, can break out of loop
        end
    end
    Ne = Ne + temp_Ne;
    No = No + temp_No;
    seq = [seq temp_seq];
    trace_x = [trace_x temp_trace_x];
    trace_y = [trace_y temp_trace_y];
end

plot(trace_x, trace_y, 'green', 'linewidth', 2); %trace out the contour length
global_trace_x = [global_trace_x trace_x];
global_trace_y = [global_trace_y trace_y];

seq_size = size(seq);

Nc = 0; %Define corner count as zero

for i=1:seq_size(2)
    if i ~= seq_size(2)
        if (seq(i)+seq(i+1) == 1)
            seq(i)+seq(i+1);
            Nc = Nc + 1; %add corner count if there is 1-0 or 0-1
        end
    end
end

pixellength = str2num(handles.pixellength);
contour_length = pixellength*(0.980*Ne + 1.406*No - 0.091*Nc);%length of measured polymer
set(handles.contourlength_static, 'string', contour_length);

%%%%%%%%%%%%%%%%%%calculate end-to-end distance%%%%%%%%%%%%%%%%%%%%%%%%%
starting_x = double(points(1,1));
starting_y = double(points(1,2));
ending_x = double(points(end,1));
ending_y = double(points(end,2));

endtoend_length = pixellength*sqrt((starting_x-ending_x)^2+(starting_y-ending_y)^2);
set(handles.endtoend_static, 'string', endtoend_length);

axes(handles.axes1)
hold on
plot(trace_x, trace_y, 'red', 'linewidth', 2); %trace out the contour length
plot(trace_x([1 end]),trace_y([1 end]), 'blue', 'linewidth', 2);
handles.points = [];
handles.contour_length = contour_length;
handles.endtoend = endtoend_length;
guidata(hObject, handles);


% --- Executes on button press in reset_pushbutton.
function reset_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to reset_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
I6 = handles.I6;
axes(handles.axes2)
hold off
imshow(I6)



function pixel_length_Callback(hObject, eventdata, handles)
% hObject    handle to pixel_length (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of pixel_length as text
%        str2double(get(hObject,'String')) returns contents of pixel_length as a double
pixellength = get(hObject, 'String');
handles.pixellength = pixellength;
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function pixel_length_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pixel_length (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in next_pushbutton.
function next_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to next_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
I5 = handles.I5; %recall new updated image after deleting measured polymer
axes(handles.axes2)
hold off
imshow(I5)


% --- Executes on button press in point_pushbutton.
function point_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to point_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
axes(handles.axes2)
hold on

temp_points = int16(ginput(1));
points = handles.points;
points = [points; temp_points]; %update points along polymer
handles.points = points;

I5 = handles.I5;
imshow(I5);
scatter(points(:,1), points(:,2), 'red', 'filled');
guidata(hObject, handles);

% --- Executes on button press in delete_pushbutton.
function delete_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to delete_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
axes(handles.axes2)
hold on

points = handles.points;
points(end,:) = [];
handles.points = points;

I5 = handles.I5;
imshow(I5);
scatter(points(:,1), points(:,2), 'red', 'filled');
guidata(hObject, handles);

% --- Executes on button press in del_points_pushbutton.
function del_points_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to del_points_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
points = [];
handles.points = points;

I5 = handles.I5;
axes(handles.axes2)
hold off
imshow(I5);
guidata(hObject, handles);


% --- Executes on button press in savefolder_pushbutton.
function savefolder_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to savefolder_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
folder_name = uigetdir;
handles.folder_name = folder_name;
set(handles.savefolder_static, 'string', folder_name);
guidata(hObject, handles);


function filename_edittext_Callback(hObject, eventdata, handles)
% hObject    handle to filename_edittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of filename_edittext as text
%        str2double(get(hObject,'String')) returns contents of filename_edittext as a double
file_name = get(hObject, 'String');
handles.file_name = file_name;
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function filename_edittext_CreateFcn(hObject, eventdata, handles)
% hObject    handle to filename_edittext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in createfile_pushbutton.
function createfile_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to createfile_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
folder_name = handles.folder_name;
file_name = handles.file_name;
file_type = strcat(file_name, '.txt');
file_path = strcat(folder_name, '\', file_type);
dlmwrite(fullfile(folder_name, file_type), []);
fid = fopen(file_path, 'w');
fprintf(fid,'Contour_length(nm) End-to-end_distance(nm)');
dlmwrite(file_path, [], '-append',  'newline', 'pc', 'delimiter', '\t', 'roffset', 1);
handles.file_path = file_path;
guidata(hObject, handles);

% --- Executes on button press in append_pushbutton.
function append_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to append_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
file_path = handles.file_path;
contour_length = handles.contour_length;
endtoend_length = handles.endtoend;
measurement = [contour_length endtoend_length];
dlmwrite(file_path, measurement, '-append', 'newline', 'pc', 'delimiter', '\t');

%%%%%%%%%plot histogram with every new input
axes(handles.axes3)
data = dlmread(file_path, '\t', 1,0);
hist(data(:,1));



function savefolder_edit_Callback(hObject, eventdata, handles)
% hObject    handle to savefolder_static (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of savefolder_static as text
%        str2double(get(hObject,'String')) returns contents of savefolder_static as a double


% --- Executes during object creation, after setting all properties.
function savefolder_static_CreateFcn(hObject, eventdata, handles)
% hObject    handle to savefolder_static (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
